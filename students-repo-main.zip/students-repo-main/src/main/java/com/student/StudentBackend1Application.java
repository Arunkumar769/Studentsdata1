package com.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentBackend1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentBackend1Application.class, args);
	}

}
